const express = require("express");
const path = require("path");
// const fs = require("fs");  
const app = express();
const port = 80;

const mongoose = require("mongoose");
// mongoose.connect('mongodb://localhost/Contact', {useNewUrlParser: true});

mongoose.connect('mongodb+srv://portfolio:portfolio123@portfoliowebsite.ni5xj.mongodb.net/Data', {
    useUnifiedTopology : true,
    useNewUrlParser : true,
}).then[console.log('Connected to mongo db!')]

var contactSchema = new mongoose.Schema({
    name: String,
    phone: String,
    email: String,
    address: String,
    desc: String,  
 });
var Contact = mongoose.model('Contact', contactSchema);

app.use('/static', express.static('static'))
app.use(express.urlencoded())

app.set('view engine', 'pug')

app.set('views', path.join(__dirname, 'views'))

app.get('/', (req, res) => {
    const params = { }
    res.status(200).render('home.pug',params);
})

app.get('/contact', (req, res) => {
    const params = { }
    res.status(200).render('contact.pug',params);
})

app.post('/contact', (req, res) => {
    var myData = new Contact(req.body);
    myData.save().then(() => {
        res.send("this item has been saved")
    }).catch(() => {
        res.status(400).send("item was not saved")
    });
    // res.status(200).render('contact.pug',params);
})

app.listen(port, () => {
    console.log(`the app started working on port ${port}`);
});